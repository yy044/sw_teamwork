import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;

public class BoardButtonFift extends JButton implements ActionListener {
	
	public BoardFrame frame;
	public int row, col;
	public SelectLevel level;

	public BoardButtonFift(BoardFrame f, int r, int c) {
		frame = f;
		row = r;
		col = c;
		setBackground(Color.WHITE);
		addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		frame.clickButtonFift(row, col);
		frame.checkSolution();
		frame.lose();
	}

}
