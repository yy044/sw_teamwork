import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class MoreButton extends JButton implements ActionListener {

	private ResultFrame rframe;
	
    public MoreButton() {
        super("More");
        //rframe = f;
        addActionListener(this);
        setBackground(Color.white);
    }

    public void actionPerformed(ActionEvent e) {
    	//rframe.dispose();
        new SelectLevel();
    }

}