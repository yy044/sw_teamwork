import java.awt.*;
import javax.swing.*;

public class BoardFrame extends JFrame {
	
	public BoardButton[][] board_button;
	public static int[][] solution = new int[5][5];
	public JPanel west;
	public JPanel north;
	public FiveRows rows;
	
	public BoardFrame(FiveRows f) {
		rows = f;
		solution = rows.getSolution();
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		JPanel p1 = new JPanel(new GridLayout(5,5));
		board_button = new BoardButton[5][5];
		for(int i=0; i<5; i++) {
			for(int j=0; j<5; j++) {
				board_button[i][j] = new BoardButton(this, i, j);
				p1.add(board_button[i][j]);
			}
		}
		west = new WestCount(f);
		north = new NorthCount(f);
		cp.add(p1, BorderLayout.CENTER);
		cp.add(west, BorderLayout.WEST);
		cp.add(north, BorderLayout.NORTH);
		setTitle("Logic");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public void clickButton(int r, int c) {
		if(solution[r][c] == 1) {
			board_button[r][c].setBackground(Color.RED);
		}
		else
			board_button[r][c].setBackground(Color.LIGHT_GRAY);
	}

}
