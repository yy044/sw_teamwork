import javax.swing.*;
import java.awt.*;

public class NorthCount extends JPanel {
	
	public static int[][] numbers; // = {{-1,-1,1,1,1,-1},{-1,1,1,1,1,1}}; // 하트
	public JLabel label;
	private FiveRows rows;
	
	public NorthCount(FiveRows r) {
		rows = r;
		setLayout(new GridLayout(2,6));
		numbers = getNorth();
		for(int i=0; i<2; i++) {
			for(int j=0; j<6; j++) {
				if(numbers[i][j] == -1)
					add(new JLabel(" "));
				else
					add(new JLabel(numbers[i][j]+""));
			}
		}
	}
	
	public int[][] getNorth(){
		int[][] numbers1 = {{-1,-1,1,1,1,-1},{-1,1,1,1,1,1}}; // 하트
		int[][] numbers2 = {{-1,-1,-1,-1,-1,-1},{-1,0,2,5,1,1}}; // 음표
		int[][] numbers3 = {{-1,-1,2,-1,2,-1},{-1,1,1,5,1,1}}; // 전투기
		int[][] numbers4 = {{-1,-1,-1,-1,-1,-1},{-1,2,3,4,3,5}}; // 하이힐
		if(rows.ranNum == 0)
			return numbers1;
		else if(rows.ranNum == 1)
			return numbers2;
		else if(rows.ranNum ==2)
			return numbers3;
		else
			return numbers4;
	}
	
	//label.setHorizontalAlignment(JLabel.RIGHT);
	/*setText("<html>"+numbers[0][0]+"<br>"+"<br>"+numbers[1][0]+"<br>"+"<br>"+numbers[2][0]+numbers[2][1]+numbers[2][2]+
			"<br>"+"<br>"+numbers[3][0]+"<br>"+"<br>"+numbers[3][1]+"<br>"+"<br>"+numbers[4][0]+"<html>");
	setHorizontalAlignment(JLabel.RIGHT);
	
	Font font = new Font("Sanserif", Font.PLAIN, 30);
	setFont(font);*/

}