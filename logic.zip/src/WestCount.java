import javax.swing.*;
import java.awt.*;

public class WestCount extends JPanel {
	
	public static int[][] numbers; // = {{-1,-1,0},{-1,-1,1},{1,1,1},{-1,1,1},{-1,-1,1}};
	public JLabel label;
	public FiveRows rows;
	
	public WestCount(FiveRows r) {
		rows = r;
		JLabel label = new JLabel();
		numbers = getWest();
		Font font = new Font("Serif", Font.PLAIN, 20);
		setLayout(new GridLayout(5,3));
		for(int i=0; i<5; i++) {
			for(int j=0; j<3; j++) {
				if(numbers[i][j] == -1){
					//label.setFont(font);
					add(new JLabel(" "));
				}
				else {
					//label.setFont(font);
					add(new JLabel(numbers[i][j]+""));
				}
			}
		}
	}
	
	public int[][] getWest(){
		int[][] number1 = {{-1,-1,0},{-1,-1,1},{1,1,1},{-1,1,1},{-1,-1,1}}; // 하트
		int[][] number2 = {{-1,-1,1},{-1,-1,2},{-1,1,1},{-1,-1,2},{-1,-1,2}}; // 음표
		int[][] number3 = {{-1,-1,1},{-1,-1,3},{-1,-1,5},{-1,-1,1},{-1,-1,3}}; // 전투기
		int[][] number4 = {{-1,-1,2},{-1,-1,3},{-1,-1,4},{-1,3,1},{-1,3,1}}; // 하이힐
		if(rows.ranNum == 0)
			return number1;
		else if(rows.ranNum == 1)
			return number2;
		else if(rows.ranNum == 2)
			return number3;
		else
			return number4;
	}
	
	//label.setHorizontalAlignment(JLabel.RIGHT);
	/*setText("<html>"+numbers[0][0]+"<br>"+"<br>"+numbers[1][0]+"<br>"+"<br>"+numbers[2][0]+numbers[2][1]+numbers[2][2]+
			"<br>"+"<br>"+numbers[3][0]+"<br>"+"<br>"+numbers[3][1]+"<br>"+"<br>"+numbers[4][0]+"<html>");
	setHorizontalAlignment(JLabel.RIGHT);
	
	Font font = new Font("Sanserif", Font.PLAIN, 30);
	setFont(font);*/

}