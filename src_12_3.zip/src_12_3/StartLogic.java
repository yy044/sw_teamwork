
public class StartLogic {

	public static void main(String[] args) {
		new SelectLevel();
	}

}
