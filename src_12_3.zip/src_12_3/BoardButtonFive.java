import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;

public class BoardButtonFive extends JButton implements ActionListener {
	
	public BoardFrame frame;
	public int row, col;
	public SelectLevel level;

	public BoardButtonFive(BoardFrame f, int r, int c) {
		frame = f;
		row = r;
		col = c;
		setBackground(Color.WHITE);
		addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		frame.clickButtonFive(row, col);
	}

}
