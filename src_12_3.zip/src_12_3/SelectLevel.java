import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SelectLevel extends JFrame implements ActionListener{

	private int level;
	private FiveRows fr = new FiveRows();
	private TenRows t = new TenRows();
	private FifteenRows ft = new FifteenRows();
	private JButton five, ten, fifteen;
	private int levelNumber;
	
	public SelectLevel() {
		Container cp = getContentPane();
		cp.setLayout(new FlowLayout());
		five = new JButton("5 X 5");
		five.setBackground(Color.WHITE);
		ten = new JButton("10 X 10");
		ten.setBackground(Color.WHITE);
		fifteen = new JButton("15 X 15");
		fifteen.setBackground(Color.WHITE);
		cp.add(five);
		cp.add(ten);
		cp.add(fifteen);
		setTitle("Select Level");
		setSize(300,70);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		five.addActionListener(this);
		ten.addActionListener(this);
		fifteen.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == five) {
			levelNumber = 5;
			new BoardFrame(fr);
		}
		else if(e.getSource() == ten) {
			levelNumber = 10;
			new BoardFrame(t);
		}
		else {
			levelNumber = 15;
			new BoardFrame(ft);
		}
	}
	
	public int levelNum() {
		return levelNumber;
	}
	
}
