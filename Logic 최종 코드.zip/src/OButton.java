import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OButton extends JButton implements ActionListener {
	
	public BoardFrame frame;
	
	public OButton(BoardFrame f) {
		super("O");
		setBackground(Color.WHITE);
		frame = f;
		addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		frame.clickOButton();
	}

}
