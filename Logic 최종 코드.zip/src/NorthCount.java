import javax.swing.*;
import java.awt.*;

public class NorthCount extends JPanel {
	
	public static int[][] numbers; // = {{-1,-1,1,1,1,-1},{-1,1,1,1,1,1}}; // 하트
	public JLabel label;
	private FiveRows five;//원래는 rows
	private TenRows ten;
	private FifteenRows fift;
	
	public NorthCount(FiveRows f) {
		setLayout(null);
		setPreferredSize(new Dimension(550,50));
		five = f;
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(445, 50));
		panel.setLayout(new GridLayout(2,5));
		numbers = getNorthFive();
		for(int i=0; i<2; i++) {
			for(int j=0; j<5; j++) {
				if(numbers[i][j] == -1)
					panel.add(new JLabel(" "));
				else
					panel.add(new JLabel(" " + numbers[i][j] + " "));
			}
		}
		panel.setBounds(80,0,445,50);
		add(panel);
	}
	
	public NorthCount(TenRows t) {
		setLayout(null);
		setPreferredSize(new Dimension(570,70));
		ten = t;
		JPanel panel = new JPanel();
		//panel.setPreferredSize(new Dimension(430, 70));
		panel.setLayout(new GridLayout(4,10));
		numbers = getNorthTen();
		for(int i=0; i<4; i++) {
			for(int j=0; j<10; j++) {
				if(numbers[i][j] == -1)
					panel.add(new JLabel(" "));
				else
					panel.add(new JLabel(" " + numbers[i][j] + " "));
			}
		}
		panel.setBounds(103,0,420,70);
		add(panel);
	}
	
	public NorthCount(FifteenRows ft) {
		setLayout(null);
		setPreferredSize(new Dimension(580,70));
		fift = ft;
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3,15));
		numbers = getNorthFift();
		for(int i=0; i<3; i++) {
			for(int j=0; j<15; j++) {
				if(numbers[i][j] == -1)
					panel.add(new JLabel(" "));
				else
					panel.add(new JLabel(" " + numbers[i][j] + " "));
			}
		}
		panel.setBounds(66,0,458,70);
		add(panel);
	}
	
	public int[][] getNorthFive(){
		int[][] numbers1 = {{-1,1,1,1,-1},{1,1,1,1,1}}; // 하트
		int[][] numbers2 = {{-1,-1,-1,-1,-1},{0,2,5,1,1}}; // 음표
		int[][] numbers3 = {{-1,2,-1,2,-1},{1,1,5,1,1}}; // 전투기
		int[][] numbers4 = {{-1,-1,-1,-1,-1},{2,3,4,3,5}}; // 하이힐
		if(five.ranNum == 0)
			return numbers1;
		else if(five.ranNum == 1)
			return numbers2;
		else if(five.ranNum ==2)
			return numbers3;
		else
			return numbers4;
	}
	
	public int[][] getNorthTen(){
		int[][] numbers1 = {{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{2,2,-1,-1,-1,-1,-1,-1,2,2},{3,3,4,4,9,9,5,6,4,4}}; // 야자수
		int[][] numbers2 = {{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,2,3,-1,6,4,1,1,-1,-1},{2,4,5,10,1,1,1,1,3,3}}; // 홍학
		int[][] numbers3 = {{-1,-1,1,-1,-1,-1,-1,1,-1,-1},{-1,-1,1,1,1,2,-1,1,1,1},{1,1,1,1,2,2,-1,1,1,1},{1,1,1,1,1,1,9,1,1,1}}; // 떨어지는 사과
		int[][] numbers4 = {{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,3,2,4,-1,-1,-1,-1,-1},{4,6,4,7,5,10,10,8,6,4}}; // 볼링공
		if(ten.ranNum == 0)
			return numbers1;
		else if(ten.ranNum == 1)
			return numbers2;
		else if(ten.ranNum ==2)
			return numbers3;
		else
			return numbers4;
	}
	
	public int[][] getNorthFift(){
		int[][] numbers1 = {{-1,-1,-1,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{3,5,5,5,12,-1,11,-1,1,1,-1,-1,-1,-1,1},{2,2,2,1,1,11,1,14,6,5,14,14,14,14,4}};//고무장화
		int[][] numbers2 = {{-1,-1,-1,-1,-1,3,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,2,4,4,4,4,-1,4,4,-1,-1,-1},{1,3,3,2,4,4,9,9,4,15,5,4,4,3,2}};//우산
		int[][] numbers3 = {{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{8,9,8,12,13,12,8,9,8,11,12,11,8,9,8}};//들소
		int[][] numbers4 = {{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},{-1,-1,-1,3,5,6,-1,7,-1,-1,-1,-1,-1,-1,-1},{3,5,9,6,3,5,15,4,12,11,10,9,6,5,3}};//카푸치노
		if(fift.ranNum == 0)
			return numbers1;
		else if(fift.ranNum == 1)
			return numbers2;
		else if(fift.ranNum ==2)
			return numbers3;
		else
			return numbers4;
	}

}