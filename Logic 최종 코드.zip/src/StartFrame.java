import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.*;

public class StartFrame extends JFrame {
	
	public StartFrame() {
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		JPanel p1 = new JPanel();
		p1.add(new JLabel("플레이할 레벨을 선택하세요."));
		JPanel p2 = new JPanel();
		p2.add(new LevelButton("Five",5));
		p2.add(new LevelButton("Ten",10));
		p2.add(new LevelButton("Fifteen",15));
		cp.add(p1,BorderLayout.NORTH);
		cp.add(p2,BorderLayout.CENTER);
		setTitle("Select level");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

}
