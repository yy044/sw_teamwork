import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class MoreButtonR extends JButton implements ActionListener {
	
	private ResultFrame r_frame;
	
    public MoreButtonR(ResultFrame f) {
        super("More");
        r_frame = f;
        addActionListener(this);
        setBackground(Color.white);
    }

    public void actionPerformed(ActionEvent e) {
    	r_frame.dispose();
        new SelectLevel();
    }

}