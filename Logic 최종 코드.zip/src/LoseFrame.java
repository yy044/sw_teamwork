import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoseFrame extends JFrame implements ActionListener{

	private BoardFrame frame;
	private MoreButtonL more = new MoreButtonL(this);
	private ExitButton exit = new ExitButton();
	
	public LoseFrame(BoardFrame f) {
		frame = f;
		Container cp = getContentPane();
		cp.setLayout(null);
		JLabel lose1 = new JLabel("이런이런~");
		JLabel lose2 = new JLabel("다음 기회에 다시 도전해보세요");
		lose1.setBounds(40, 10, 300, 30);
		lose1.setHorizontalAlignment(JLabel.CENTER);
		lose2.setBounds(40, 30, 300, 30);
		lose2.setHorizontalAlignment(JLabel.CENTER);
		more.setBounds(95, 70, 70, 23);
		exit.setBounds(200, 70, 70, 23);
		cp.add(lose1);
		cp.add(lose2);
		cp.add(more);
		cp.add(exit);
		setTitle("Lose");
		setSize(400,160);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent e) {
	}
	
}
