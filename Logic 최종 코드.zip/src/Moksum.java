import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Moksum extends JButton implements ActionListener{
	
	private JButton moksum;
	
	public Moksum() {
		setText("♡");
		setBackground(Color.PINK);
	}
	
	public void actionPerformed(ActionEvent e) {
		
	}
	
}