import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class XButton extends JButton implements ActionListener {
	
	public BoardFrame frame;
	
	public XButton(BoardFrame f) {
		super("X");
		setBackground(Color.GRAY);
		frame = f;
		addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		frame.clickXButton();
	}

}
