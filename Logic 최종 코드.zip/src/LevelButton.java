import javax.swing.*;
import java.awt.event.*;

public class LevelButton extends JButton implements ActionListener {
	
	public int level;
	
	public LevelButton(String s, int n) {
		setText(s);
		level = n;
	}

	public void actionPerformed(ActionEvent e) {
		
	}

}
