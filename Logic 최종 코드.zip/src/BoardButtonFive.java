import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;

public class BoardButtonFive extends JButton implements ActionListener {
	
	public BoardFrame frame;
	public FiveRows five;
	public int row, col;
	public SelectLevel level;
	public boolean x_select = false;
	public boolean solved = false;

	public BoardButtonFive(BoardFrame f, int r, int c) {
		frame = f;
		row = r;
		col = c;
		setBackground(Color.WHITE);
		addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		frame.clickButtonFive(row, col);
		frame.checkSolution();
		frame.lose();
	}
	
	public void x_check() {
		if(x_select) x_select = false;
		else x_select = true;
	}
	
	public boolean x_checked() {
		return x_select;
	}

	public void solved() {
		solved = true;
	}
	
	public boolean isSolved() {
		return solved;
	}

}
