import java.awt.*;
import javax.swing.*;

public class BoardFrame extends JFrame {
	
	public BoardButtonFive[][] board_button5;
	public BoardButtonTen[][] board_button10;
	public BoardButtonFift[][] board_button15;
	public static int[][] solutionFive = new int[5][5];
	public static int[][] solutionTen = new int[10][10];
	public static int[][] solutionFift = new int[15][15];
	public JPanel west;
	public JPanel north;
	public JPanel south = new JPanel();
	public JPanel east = new JPanel();
	public FiveRows five;//원래는 rows
	public TenRows ten;
	public FifteenRows fift;
	public int one_count_solution = 0;
	public int one_count = 0;
	
	public BoardFrame(FiveRows fv) {
		five = fv;
		solutionFive = five.getSolution();
		for (int i=0; i<5; i++) {
			for (int j=0; j<5; j++) {
				one_count_solution += solutionFive[i][j];
			}
		}
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout(7,5));
		JPanel p1 = new JPanel(new GridLayout(5,5));
		board_button5 = new BoardButtonFive[5][5];
		for(int i=0; i<5; i++) {
			for(int j=0; j<5; j++) {
				board_button5[i][j] = new BoardButtonFive(this, i, j);
				p1.add(board_button5[i][j]);
			}
		}
		
		west = new WestCount(fv);
		north = new NorthCount(fv);
		cp.add(p1, BorderLayout.CENTER);
		cp.add(west, BorderLayout.WEST);
		cp.add(north, BorderLayout.NORTH);
		cp.add(south, BorderLayout.SOUTH);
		cp.add(east, BorderLayout.EAST);
		
		setTitle("Logic");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
	}
	
	public BoardFrame(TenRows t) {
		ten = t;
		solutionTen = ten.getSolution();
		for (int i=0; i<10; i++) {
			for (int j=0; j<10; j++) {
				one_count_solution += solutionTen[i][j];
			}
		}
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout(7,5));
		JPanel p1 = new JPanel(new GridLayout(10,10));
		board_button10 = new BoardButtonTen[10][10];
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				board_button10[i][j] = new BoardButtonTen(this, i, j);
				p1.add(board_button10[i][j]);
			}
		}
		
		west = new WestCount(t);
		north = new NorthCount(t);
		cp.add(p1, BorderLayout.CENTER);
		cp.add(west, BorderLayout.WEST);
		cp.add(north, BorderLayout.NORTH);
		cp.add(south, BorderLayout.SOUTH);
		cp.add(east, BorderLayout.EAST);
		
		setTitle("Logic");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public BoardFrame(FifteenRows ft) {
		fift = ft;
		solutionFift = fift.getSolution();
		for (int i=0; i<15; i++) {
			for (int j=0; j<15; j++) {
				one_count_solution += solutionFift[i][j];
			}
		}
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout(7,5));
		JPanel p1 = new JPanel(new GridLayout(15,15));
		board_button15 = new BoardButtonFift[15][15];
		for(int i=0; i<15; i++) {
			for(int j=0; j<15; j++) {
				board_button15[i][j] = new BoardButtonFift(this, i, j);
				p1.add(board_button15[i][j]);
			}
		}
		
		west = new WestCount(ft);
		north = new NorthCount(ft);
		cp.add(p1, BorderLayout.CENTER);
		cp.add(west, BorderLayout.WEST);
		cp.add(north, BorderLayout.NORTH);
		cp.add(south, BorderLayout.SOUTH);
		cp.add(east, BorderLayout.EAST);
		
		setTitle("Logic");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	public void clickButtonFive(int r, int c) {
		if(solutionFive[r][c] == 1) {
			board_button5[r][c].setBackground(Color.BLACK);
			one_count++;
		}
		else
			board_button5[r][c].setBackground(Color.LIGHT_GRAY);
	}
	
	public void clickButtonTen(int r, int c) {
		if(solutionTen[r][c] == 1) {
			board_button10[r][c].setBackground(Color.BLACK);
			one_count++;
		}
		else
			board_button10[r][c].setBackground(Color.LIGHT_GRAY);
	}
	
	public void clickButtonFift(int r, int c) {
		if(solutionFift[r][c] == 1) {
			board_button15[r][c].setBackground(Color.BLACK);
			one_count++;
		}
		else
			board_button15[r][c].setBackground(Color.LIGHT_GRAY);
	}
	
	public void checkSolution() {
		if (one_count == one_count_solution) {
			dispose();
			new ResultFrame();
		}
	}
}
