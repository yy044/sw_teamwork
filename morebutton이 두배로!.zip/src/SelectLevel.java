import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SelectLevel extends JFrame implements ActionListener{

	private int level;
	private FiveRows fr = new FiveRows();
	private TenRows t = new TenRows();
	private FifteenRows ft = new FifteenRows();
	private JButton five, ten, fifteen;
	private int levelNumber;
	
	public SelectLevel() {
		Container cp = getContentPane();
		cp.setLayout(null);
		JLabel game = new JLabel("네모네모 로직 게임에 오신 걸 환영합니다.");
		JLabel level = new JLabel("게임의 난이도를 선택해주세요.");
		game.setBounds(50, 20, 300, 30);
		game.setHorizontalAlignment(JLabel.CENTER);
		level.setBounds(50, 40, 300, 30);
		level.setHorizontalAlignment(JLabel.CENTER);
		five = new JButton("5 X 5");
		five.setBackground(Color.WHITE);
		five.setBounds(50, 80, 80, 30);
		ten = new JButton("10 X 10");
		ten.setBackground(Color.WHITE);
		ten.setBounds(150, 80, 80, 30);
		fifteen = new JButton("15 X 15");
		fifteen.setBackground(Color.WHITE);
		fifteen.setBounds(250, 80, 80, 30);
		// 이미지 넣기 (5X5)
		JLabel label1 = new JLabel();
		ImageIcon icon1 = new ImageIcon(SelectLevel.class.getResource("res/55.jpg"));
		Image img1 = icon1.getImage();
		Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
		ImageIcon changeicon1 = new ImageIcon(change1);
		JLabel label11 = new JLabel(changeicon1);
		label11.setIcon(changeicon1);
		label11.setBounds(50, 125, 80, 80);
		label11.setHorizontalAlignment(JLabel.CENTER);
		cp.add(label11);
		// 이미지 넣기 (10X10)
		JLabel label2 = new JLabel();
		ImageIcon icon2 = new ImageIcon(SelectLevel.class.getResource("res/1010.jpg"));
		Image img2 = icon2.getImage();
		Image change2 = img2.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
		ImageIcon changeicon2 = new ImageIcon(change2);
		JLabel label22 = new JLabel(changeicon2);
		label22.setIcon(changeicon2);
		label22.setBounds(150, 125, 80, 80);
		label22.setHorizontalAlignment(JLabel.CENTER);
		cp.add(label22);
		// 이미지 넣기 (15X15)
		JLabel label3 = new JLabel();
		ImageIcon icon3 = new ImageIcon(SelectLevel.class.getResource("res/1515.jpg"));
		Image img3 = icon3.getImage();
		Image change3 = img3.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
		ImageIcon changeicon3 = new ImageIcon(change3);
		JLabel label33 = new JLabel(changeicon3);
		label33.setIcon(changeicon3);
		label33.setBounds(250, 125, 80, 80);
		label33.setHorizontalAlignment(JLabel.CENTER);
		cp.add(label33);
		
		cp.add(game);
		cp.add(level);
		cp.add(five);
		cp.add(ten);
		cp.add(fifteen);
		setTitle("Select Level");
		setSize(400,275);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		five.addActionListener(this);
		ten.addActionListener(this);
		fifteen.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == five) {
			levelNumber = 5;
			dispose();
			new BoardFrame(fr);
		}
		else if(e.getSource() == ten) {
			levelNumber = 10;
			dispose();
			new BoardFrame(t);
		}
		else {
			levelNumber = 15;
			dispose();
			new BoardFrame(ft);
		}
	}
	
	public int levelNum() {
		return levelNumber;
	}
	
}
