import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Moksum extends JButton implements ActionListener{
	
	private JButton moksum;
	
	public Moksum() {
		setBackground(Color.BLUE);
	}
	
	public void actionPerformed(ActionEvent e) {
		
	}
	
}