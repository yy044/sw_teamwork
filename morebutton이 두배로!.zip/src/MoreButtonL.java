import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class MoreButtonL extends JButton implements ActionListener {
	
	private LoseFrame l_frame;
	
    public MoreButtonL(LoseFrame f) {
    	super("More");
    	l_frame = f;
    	addActionListener(this);
    	setBackground(Color.white);
    }

    public void actionPerformed(ActionEvent e) {
    	l_frame.dispose();
        new SelectLevel();
    }

}