import javax.swing.*;

import java.awt.Color;
import java.awt.event.*;

public class BoardButtonTen extends JButton implements ActionListener {
	
	public BoardFrame frame;
	public int row, col;
	public SelectLevel level;

	public BoardButtonTen(BoardFrame f, int r, int c) {
		frame = f;
		row = r;
		col = c;
		setBackground(Color.WHITE);
		addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		frame.clickButtonTen(row, col);
		frame.checkSolution();
		frame.lose();
	}

}
