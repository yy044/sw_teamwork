import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class MoreButton extends JButton implements ActionListener {
	
	private ResultFrame frame;
	
    public MoreButton(ResultFrame f) {
        super("More");
        frame = f;
        addActionListener(this);
        setBackground(Color.white);
    }

    public void actionPerformed(ActionEvent e) {
    	frame.dispose();
        new SelectLevel();
    }

}