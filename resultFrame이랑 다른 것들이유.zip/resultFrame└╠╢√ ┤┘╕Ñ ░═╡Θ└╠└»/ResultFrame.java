import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ResultFrame extends JFrame implements ActionListener {
	
	private MoreButton more = new MoreButton();
	private ExitButton exit = new ExitButton();
	private FiveRows five = new FiveRows();
	public BoardFrame frame;
	
	public ResultFrame(BoardFrame f) {
		frame = f;
		Container cp = getContentPane();
		cp.setLayout(null);
		JLabel end = new JLabel("축하합니다! 퍼즐보드를 완성하였습니다");
		end.setBounds(40, 10, 300, 30);
		end.setHorizontalAlignment(JLabel.CENTER);
		//level.setBounds(50, 40, 300, 30);
		//level.setHorizontalAlignment(JLabel.CENTER);
		more.setBounds(95, 180, 70, 23);
		exit.setBounds(200, 180, 70, 23);
		
		if(frame.one_count_solution == 8) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/550.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 하트");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
			
		}
		else if(frame.one_count_solution == 9) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/551.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 음표");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 13) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/552.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 전투기");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 17) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/553.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 하이힐");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 59) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/10100.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 야자수");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 48) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/10101.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 홍학");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 39) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/10102.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 떨어지는 사과");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 73) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/10103.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 볼링공");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 150) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/15150.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 고무장화");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 101) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/15151.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 우산");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 146) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/15152.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 호박");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		else if(frame.one_count_solution == 127) {
			JLabel label1 = new JLabel();
			ImageIcon icon1 = new ImageIcon(ResultFrame.class.getResource("result/15153.jpg"));
			Image img1 = icon1.getImage();
			Image change1 = img1.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
			ImageIcon changeicon1 = new ImageIcon(change1);
			JLabel label11 = new JLabel(changeicon1);
			label11.setIcon(changeicon1);
			label11.setIcon(changeicon1);
			label11.setBounds(150,80,80,80);
			label11.setHorizontalAlignment(JLabel.CENTER);
			cp.add(label11);
			JLabel label2 = new JLabel("완성된 그림 : 하트");
			label2.setBounds(120, 35, 300, 30);
			cp.add(label2);
		}
		
		cp.add(end);
		cp.add(more);
		cp.add(exit);
		setTitle("Result");
		setSize(400,250);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		
	}
	
	public void actionPerformed(ActionEvent e) {
	}
	
	
}
