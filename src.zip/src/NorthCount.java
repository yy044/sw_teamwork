import javax.swing.*;
import java.awt.*;

public class NorthCount extends JPanel {
	
	public static int[][] numbers = {{-1,-1,1,1,1,-1},{-1,1,1,1,1,1}};
	public JLabel label;
	
	public NorthCount() {
		setLayout(new GridLayout(2,6));
		for(int i=0; i<2; i++) {
			for(int j=0; j<6; j++) {
				if(numbers[i][j] == -1)
					add(new JLabel(" "));
				else
					add(new JLabel(numbers[i][j]+""));
			}
		}
	}
	
	//label.setHorizontalAlignment(JLabel.RIGHT);
	/*setText("<html>"+numbers[0][0]+"<br>"+"<br>"+numbers[1][0]+"<br>"+"<br>"+numbers[2][0]+numbers[2][1]+numbers[2][2]+
			"<br>"+"<br>"+numbers[3][0]+"<br>"+"<br>"+numbers[3][1]+"<br>"+"<br>"+numbers[4][0]+"<html>");
	setHorizontalAlignment(JLabel.RIGHT);
	
	Font font = new Font("Sanserif", Font.PLAIN, 30);
	setFont(font);*/

}