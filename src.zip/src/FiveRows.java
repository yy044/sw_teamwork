import java.util.*;

public class FiveRows {
	
	public int[][] solution1;
	public int[][] solution2;
	public int[][] solution3;
	public int[][] solution4;
	
	public FiveRows() {
		int[][] solution1 = {{0,0,0,0,0},{0,1,0,1,0},{1,0,1,0,1},{0,1,0,1,0},{0,0,1,0,0}};
		int[][] solution2 = {{0,1,1,1,0},{0,1,1,1,0},{0,1,1,1,0},{0,1,1,1,0},{0,1,1,1,0}};
		int[][] solution3 = {{0,0,0,0,0},{0,0,0,0,0},{0,0,1,0,0},{0,0,0,0,0},{0,0,0,0,0}};
		int[][] solution4 = {{1,1,1,1,1},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{1,1,1,1,1}};
	}
	
	public int[][] getSolution(){
		Random random = new Random();
		int n = random.nextInt(4);
		/*if(n == 0)
			return solution1;
		else if(n == 1)
			return solution2;
		else if(n == 2)
			return solution3;
		else
			return solution4;*/
		return solution1;
	}

}
