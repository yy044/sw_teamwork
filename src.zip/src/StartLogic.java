
public class StartLogic {

	public static void main(String[] args) {
		FiveRows rows = new FiveRows();
		new BoardFrame(rows);
	}

}
